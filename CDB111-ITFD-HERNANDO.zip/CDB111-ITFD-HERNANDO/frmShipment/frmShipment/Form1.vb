﻿Public Class frmShipment

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles btnClose.Click

    End Sub
End Class

﻿Imports System.Data
Imports System.Data.OleDb
Module mdlConnection
    Dim conStr As String = My.Settings.CDB111_ITFD_HERNANDOConnectionString

    Public Function Execute(ByVal command As String) As DataTable
        Dim cn As New OleDbConnection(conStr)
        Dim da As New OleDbDataAdapter(command, cn)
        Dim cb As New OleDbCommandBuilder(da)
        Dim dt As New DataTable
        da.Fill(dt)
        Return dt
    End Function
End Module

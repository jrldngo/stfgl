﻿Public Class Form1

    Private Sub refreshData()
        Dim dt As New DataTable
        dt = Execute("SELECT * FROM Captain")
        'dt = Execute("SELECT * FROM Captain WHERE CaptainName = 'Jack Sparrow'")
        dgvOutput.DataSource = dt
    End Sub
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim dt As New DataTable
        dt = Execute("SELECT * FROM Captain")
        'dt = Execute("SELECT * FROM Captain WHERE CaptainName = 'Jack Sparrow'")
        dgvOutput.DataSource = dt
    End Sub

    Private Sub txtSearch_TextChanged(sender As Object, e As EventArgs) Handles txtSearch.TextChanged
        Dim dt As New DataTable
        dt = Execute("SELECT * FROM Captain WHERE CaptainName LIKE '%" & txtSearch.Text & "%'")
        dgvOutput.DataSource = dt
    End Sub

    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        'Execute("INSERT INTO Captain VALUES('C003, 'Miguel')")
        Execute("INSERT INTO Captain VALUES('" & txtCaptainID.Text & "', '" & txtCaptainName.Text & "')")
        refreshData()
    End Sub

    Private Sub dgvOutput_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgvOutput.CellContentClick

    End Sub

    Private Sub dgvOutput_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgvOutput.CellClick
        txtCaptainID.Text = dgvOutput.SelectedRows(0).Cells(0).Value
        txtCaptainName.Text = dgvOutput.SelectedRows(0).Cells(1).Value
    End Sub

    Private Sub btnEdit_Click(sender As Object, e As EventArgs) Handles btnEdit.Click
        Execute("UPDATE Captain SET CaptainID = '" & txtCaptainID.Text & "', CaptainName = '" & txtCaptainName.Text & "' WHERE CaptainID = '" & dgvOutput.SelectedRows(0).Cells(0).Value & "'")
        refreshData()
    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        Execute("DELETE FROM Captain WHERE CaptainID = '" & dgvOutput.SelectedRows(0).Cells(0).Value & "'")
        refreshData()
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class

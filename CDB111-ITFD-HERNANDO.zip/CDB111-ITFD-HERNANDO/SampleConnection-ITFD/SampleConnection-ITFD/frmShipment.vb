﻿Public Class frmShipment
    Private Sub refreshData()
        Dim dt As New DataTable
        dt = Execute("SELECT * FROM Shipment")
        'dt = Execute("SELECT * FROM Captain WHERE CaptainName = 'Jack Sparrow'")
        dgvShipment.DataSource = dt
    End Sub
    Private Sub frmShipment_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim dt As New DataTable
        dt = Execute("SELECT s.ShipmentID, s.ShipmentDate, s.ExpectedArrivalDate, s.Origin, s.Destination, s.ShipNumber, c.CaptainName FROM Shipment AS s INNER JOIN Captain AS c ON s.CaptainID = c.CaptainID")
        dgvShipment.DataSource = dt

    End Sub

    Private Sub dgvShipment_CellContentClick(sender As Object, e As DataGridViewCellEventArgs)

    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub

    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        Execute("INSERT INTO Shipment VALUES('" & txtShipmentID.Text & "', '" & txtShipmentNumber.Text & "', '" & txtDestination.Text & "', '" & txtOrigin.Text & "', '" & txtCaptain.Text & "')")
        refreshData()
    End Sub

    Private Sub btnEdit_Click(sender As Object, e As EventArgs) Handles btnEdit.Click
        Execute("UPDATE Shipment SET ShipmentID = '" & txtShipmentID.Text & "', ShipmentNumber = '" & txtShipmentNumber.Text & "' WHERE ShipmentID = '" & dgvShipment.SelectedRows(0).Cells(0).Value & "'")
        refreshData()
    End Sub

    Private Sub dgvShipment_CellContentClick_1(sender As Object, e As DataGridViewCellEventArgs) Handles dgvShipment.CellContentClick

    End Sub

    Private Sub dgvShipment_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgvShipment.CellClick
        txtShipmentID.Text = dgvShipment.SelectedRows(0).Cells(0).Value
        txtCaptain.Text = dgvShipment.SelectedRows(0).Cells(6).Value
        txtShipmentNumber.Text = dgvShipment.SelectedRows(0).Cells(5).Value
        txtDestination.Text = dgvShipment.SelectedRows(0).Cells(4).Value
        txtOrigin.Text = dgvShipment.SelectedRows(0).Cells(3).Value
        dtpExpectedArrival.Text = dgvShipment.SelectedRows(0).Cells(2).Value
        dtpShipmentDate.Text = dgvShipment.SelectedRows(0).Cells(1).Value
    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        Execute("DELETE FROM Shipment WHERE ShipmentID = '" & dgvShipment.SelectedRows(0).Cells(0).Value & "'")
        refreshData()
    End Sub
End Class